import requests
from typing import Dict
import time
import json

base_url = "https://api.fabric.microsoft.com/v1"

def create_ontology_item(
        workspace_id: str, 
        access_token: str,
        ontology_item_name:str,
        ontology_definition:dict = None,
        base_url: str = "https://api.fabric.microsoft.com/v1") -> Dict:
    
    url = f"{base_url}/workspaces/{workspace_id}/ontologies"
    payload = {"displayName": ontology_item_name}
    if ontology_definition:
        payload["definition"] = ontology_definition

    response = call_api(access_token, url, "post", payload)
    if response.status_code == 202:
        response = poll_operation_result(access_token,response)
        
    return response


def call_api(token, url, method, payload=None) -> Dict:
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json; charset=UTF-8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    try:
        response = {}
        if method.lower() == "post":
            json_payload = json.dumps(payload)
            response = requests.post(url, data=json_payload, headers=headers)
        else:
            response = requests.get(url, headers=headers)

        return response
    except Exception as e:
        print(f"Error calling REST API: {e}")
        return None
    
def poll_operation_result(access_token,response):
    location = response.headers["Location"]
    ops_response = ""
    while True:
        async_response = call_api(access_token,location, "get")
        async_status = async_response.json().get("status").lower()
        if async_status != "running":
            print(f"Operation response: {async_response.json()}")
            ops_response = call_api(access_token,f"{location}/result", "get")
            break

        time.sleep(3)

    return ops_response