from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import re
import uuid
from collections import defaultdict
from typing import IO, DefaultDict, Dict, List, Optional, Tuple, Any, Union
from zipfile import Path, ZipFile
import pandas as pd
import importlib.resources as ir

# -----------------------------
# Core helpers
# -----------------------------

_ALLOWED_VALUE_TYPES = ["String", "Boolean", "DateTime", "BigInt", "Double", "Object"]
_ALLOWED_DATABINDING_TYPES = ["TimeSeries", "NonTimeSeries"]
_ALLOWED_SOURCE_TYPES = [
    "LakehouseTable",
    "KustoTable",
]  # KustoTable = Eventhouse binding

def read_zip_bytes_from_ontology_package(ontology_package_zip_path: str, inner_zip_name:str ) -> bytes:
    ontology_zip_path = str(ontology_package_zip_path)

    with ZipFile(ontology_zip_path, "r") as outer:
        with outer.open(f"{inner_zip_name}.zip") as inner_zip_bytes:
           return inner_zip_bytes.read()


def data_type_validation(value_type: str) -> None:
    if value_type not in _ALLOWED_VALUE_TYPES:
        raise ValueError(
            f"Invalid data type: {value_type!r}. Allowed values are: {_ALLOWED_VALUE_TYPES}"
        )


def make_64bit_id(seed: str) -> int:
    """Deterministically generate a positive 64-bit integer from a string seed."""
    h = hashlib.sha256(seed.encode("utf-8")).digest()
    val = int.from_bytes(h[:8], "big") & ((1 << 63) - 1)  # ensure positive
    return val if val != 0 else 1


def make_deterministic_guid(seed: str) -> str:
    """
    Deterministically generate a GUID (UUIDv5) from a string seed.
    (Useful when CSV doesn't provide BindingId/ContextualizationId.)
    """
    return str(uuid.uuid5(uuid.NAMESPACE_URL, seed))


def sanitize_name(name: str, prefix: str) -> str:
    """
    Conform to Fabric name regex:
      ^[a-zA-Z][a-zA-Z0-9_-]{0,127}$
    """
    clean = re.sub(r"[^A-Za-z0-9_-]", "_", (name or "").strip())
    if not clean or not clean[0].isalpha():
        clean = f"{prefix}_{clean}" if clean else f"{prefix}"
    return clean[:128]


def _truthy(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y", "t"}


def _s(row: Dict[str, str], key: str) -> str:
    return (row.get(key) or "").strip()


def _has_any(row: Dict[str, str], keys: List[str]) -> bool:
    return any((_s(row, k) != "") for k in keys)


def encode_base64_json(obj) -> str:
    """JSON-serialize and base64-encode a payload for Fabric's InlineBase64."""
    data = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.b64encode(data).decode("ascii")


def _parse_list(value: str) -> List[str]:
    """
    Parse a delimited list from CSV. Supports commas, semicolons, pipes.
    """
    if not value:
        return []
    parts = re.split(r"[,\;\|]+", value)
    return [p.strip() for p in parts if p.strip()]


def _normalize_guid(value: str) -> str:
    """
    Validate and normalize GUID string (lowercase canonical).
    Raises ValueError if invalid.
    """
    u = uuid.UUID(value.strip())
    return str(u)


# -----------------------------
# CSV loading
# -----------------------------


def load_entity_rows(entity_csv_path_or_bytes: Union[str, bytes]) -> DefaultDict[str, List[Dict[str, str]]]:
    rows_by_entity: DefaultDict[str, List[Dict[str, str]]] = defaultdict(list)
    with open_csv_text(entity_csv_path_or_bytes) as f:
        reader = csv.DictReader(f)
        for row in reader:
            et_name = _s(row, "EntityTypeName")
            if not et_name:
                continue
            rows_by_entity[et_name].append(row)
    return rows_by_entity


def open_csv_text(source: Union[str, Path, bytes]) -> IO[str]:
    """
    Returns a text-mode file-like object suitable for csv.DictReader.

    - If source is str/Path: opens a file on disk.
    - If source is bytes: wraps in TextIOWrapper over BytesIO.
    """
    if isinstance(source, (str, Path)):
        return open(source, newline="", encoding="utf-8")
    elif isinstance(source, (bytes, bytearray, io.BytesIO)):
        return io.TextIOWrapper(source, encoding="utf-8", newline="")
    else:
        raise TypeError(f"Unsupported CSV source type: {type(source)!r}")

# -----------------------------
# Entity types + properties
# -----------------------------


def build_entity_types(entity_csv_path_or_bytes: Union[str, bytes], namespace: str) -> Dict[str, Dict]:
    """
    Build EntityType definitions (including properties + timeseriesProperties) from EntityTypes CSV.

    Required columns:
      - EntityTypeName
      - PropertyName
      - PropertyDataType

    Optional:
      - EntityTypeDisplayName
      - IsIdentifier
      - IsDisplayName
      - IsTimeseries   (if true, property is placed under timeseriesProperties)
    """
    rows_by_entity = load_entity_rows(entity_csv_path_or_bytes)

    entity_types: Dict[str, Dict] = {}
    for raw_entity_name, rows in rows_by_entity.items():
        display_name = (_s(rows[0], "EntityTypeDisplayName") or raw_entity_name).strip()
        name = sanitize_name(display_name, prefix="E")
        et_id = str(make_64bit_id(f"entity:{namespace}:{raw_entity_name}"))

        entity_types[raw_entity_name] = {
            "id": et_id,
            "namespace": namespace,
            "baseEntityTypeId": None,
            "name": name,
            "entityIdParts": [],
            "displayNamePropertyId": None,
            "namespaceType": "Custom",
            "visibility": "Visible",
            "properties": [],
            "timeseriesProperties": [],
        }

    add_entity_properties(entity_types, rows_by_entity)
    return entity_types


def add_entity_properties(
    entity_types: Dict[str, Dict], rows_by_entity: Dict[str, List[Dict[str, str]]]
) -> None:
    """
    Populate EntityType.properties and EntityType.timeseriesProperties.
    Also sets entityIdParts and displayNamePropertyId with sensible fallbacks.
    """
    for raw_entity_name, rows in rows_by_entity.items():
        et = entity_types.get(raw_entity_name)
        if not et:
            continue

        entity_id_parts: List[str] = []
        display_prop_id: Optional[str] = None

        # de-dupe by raw property name (case-insensitive)
        seen_props: set[str] = set()

        for row in rows:
            raw_prop_name = _s(row, "PropertyName")
            if not raw_prop_name:
                continue
            key = raw_prop_name.lower()
            if key in seen_props:
                continue
            seen_props.add(key)

            prop_name = sanitize_name(raw_prop_name, prefix="P")
            value_type = (_s(row, "PropertyDataType") or "String") or "String"
            data_type_validation(value_type)

            pid = str(make_64bit_id(f"prop:{et['id']}|{raw_prop_name}"))
            prop_def = {
                "id": pid,
                "name": prop_name,
                "redefines": None,
                "baseTypeNamespaceType": None,
                "valueType": value_type,
            }

            is_id = _truthy(row.get("IsIdentifier"))
            is_display = _truthy(row.get("IsDisplayName"))
            is_timeseries = _truthy(row.get("IsTimeseries"))

            # Keys must be static in practice; if marked identifier, keep it in properties.
            if is_id:
                is_timeseries = False

            if is_timeseries:
                et["timeseriesProperties"].append(prop_def)
            else:
                et["properties"].append(prop_def)

            if is_id:
                entity_id_parts.append(pid)
            if is_display and display_prop_id is None:
                display_prop_id = pid

        # Fallbacks
        all_props = (et.get("properties") or []) + (
            et.get("timeseriesProperties") or []
        )
        if all_props:
            if not entity_id_parts:
                # Prefer first static property if present, else any property
                if et["properties"]:
                    entity_id_parts = [et["properties"][0]["id"]]
                else:
                    entity_id_parts = [all_props[0]["id"]]
            if display_prop_id is None:
                display_prop_id = all_props[0]["id"]

        et["entityIdParts"] = entity_id_parts
        et["displayNamePropertyId"] = display_prop_id


def build_property_lookup(entity_types: Dict[str, Dict]) -> Dict[str, Dict[str, str]]:
    """
    Build lookup: { entityTypeId -> { sanitizedPropertyNameLower -> propertyId } }
    Useful for turning CSV rows into propertyBindings.
    """
    lookup: Dict[str, Dict[str, str]] = {}
    for et in entity_types.values():
        m: Dict[str, str] = {}
        for p in et.get("properties") or []:
            m[p["name"].lower()] = p["id"]
        for p in et.get("timeseriesProperties") or []:
            m[p["name"].lower()] = p["id"]
        lookup[et["id"]] = m
    return lookup


# -----------------------------
# Relationship types
# -----------------------------


def build_relationship_types(
    relationship_csv_path_or_bytes: Union[str, bytes],
    entity_types: Dict[str, Dict],
    namespace: str,
) -> List[Dict]:
    """
    Relationship CSV expected columns:
      - RelationshipName (optional)
      - SourceEntityTypeName (required)
      - TargetEntityTypeName (required)
    """
    relationships: List[Dict] = []

    with open_csv_text(relationship_csv_path_or_bytes) as f:
        reader = csv.DictReader(f)
        for row in reader:
            src_name = _s(row, "SourceEntityTypeName")
            tgt_name = _s(row, "TargetEntityTypeName")
            if not src_name or not tgt_name:
                continue

            src_et = entity_types.get(src_name)
            tgt_et = entity_types.get(tgt_name)
            if not src_et or not tgt_et:
                continue

            raw_rel_name = _s(row, "RelationshipName") or f"{src_name}_to_{tgt_name}"
            rel_name = sanitize_name(raw_rel_name, prefix="R")

            seed = f"{namespace}:{src_et['id']}->{tgt_et['id']}|{rel_name}"
            rid = str(make_64bit_id(f"rel:{seed}"))

            relationships.append(
                {
                    "namespace": namespace,
                    "id": rid,
                    "name": rel_name,
                    "namespaceType": "Custom",
                    "source": {"entityTypeId": src_et["id"]},
                    "target": {"entityTypeId": tgt_et["id"]},
                    # Keep original names in case you want to match later:
                    "_srcEntityTypeName": src_name,
                    "_tgtEntityTypeName": tgt_name,
                    "_rawRelationshipName": raw_rel_name,
                }
            )

    return relationships


# -----------------------------
# Entity DataBindings
# -----------------------------


def build_entity_type_data_bindings(
    entity_csv_path_or_bytes: Union[str, bytes],
    entity_types: Dict[str, Dict],
    namespace: str,
    input_workspace_id: str = "",
    input_lakehouse_item_id: str = "",
    input_lakehouse_schema_name: str = "",
    input_eventhouse_item_id: str = "",
    input_eventhouse_cluster_uri: str = "",
    input_eventhouse_database_name: str = "",
) -> List[Dict[str, Any]]:
    """
    Builds DataBinding files (parts) per entity type from OPTIONAL columns in the entity CSV.

    OPTIONAL columns (repeat per property row; you can leave blank on rows you don't want bound):
      - BindingId                (GUID optional; if empty, generated deterministically)
      - DataBindingType          (TimeSeries | NonTimeSeries)
      - TimestampColumnName      (required when DataBindingType=TimeSeries)
      - BindingSourceColumnName  (optional; defaults to PropertyName)

      - SourceType               (LakehouseTable | KustoTable)
      - WorkspaceId              (GUID)
      - SourceItemId             (GUID)  (ArtifactId of lakehouse/eventhouse)
      - SourceTableName          (string)
      - SourceSchema             (string optional)

      - ClusterUri               (required if SourceType=KustoTable)
      - DatabaseName             (required if SourceType=KustoTable)

    Returns list of:
      { "entityTypeId": "...", "dataBindingId": "...", "dataBinding": { ... } }
    """
    rows_by_entity = load_entity_rows(entity_csv_path_or_bytes)

    # Map: (entityTypeId, bindingKey) -> accumulator
    bindings_acc: Dict[Tuple[str, str], Dict[str, Any]] = {}

    # Build a raw-property-name -> propertyId lookup too (more forgiving for CSV)
    # We accept either "PropertyName" (raw) or "TargetPropertyName" if you add it.
    raw_prop_to_id: Dict[str, Dict[str, str]] = {}
    for et_name, et in entity_types.items():
        m: Dict[str, str] = {}
        for p in (et.get("properties") or []) + (et.get("timeseriesProperties") or []):
            # store by BOTH sanitized + original-ish forms (case-insensitive)
            m[p["name"].lower()] = p["id"]
        raw_prop_to_id[et_name] = m

    for et_name, rows in rows_by_entity.items():
        et = entity_types.get(et_name)
        if not et:
            continue

        for row in rows:
            # detect whether this row is intended to participate in a data binding
            required_columns = [
                "DataBindingType",
                "SourceType",
                "SourceTableName",
                "BindingSourceColumnName",
            ]
            if not _has_any(row, required_columns):
                continue

            if any(not str(row.get(c, "")).strip() for c in required_columns):
                continue

            db_type = _s(row, "DataBindingType") or "NonTimeSeries"
            if db_type not in _ALLOWED_DATABINDING_TYPES:
                raise ValueError(
                    f"Invalid DataBindingType {db_type!r}. Allowed: {_ALLOWED_DATABINDING_TYPES}"
                )

            source_type = _s(row, "SourceType") or "LakehouseTable"
            if source_type not in _ALLOWED_SOURCE_TYPES:
                raise ValueError(
                    f"Invalid SourceType {source_type!r}. Allowed: {_ALLOWED_SOURCE_TYPES}"
                )
            
            if(input_workspace_id):
                workspace_id = _normalize_guid(input_workspace_id)
            else:
                workspace_id = _normalize_guid(_s(row, "WorkspaceId")) if _s(row, "WorkspaceId") else ""
                
            if(input_lakehouse_item_id):
                item_id = _normalize_guid(input_lakehouse_item_id)
            else:
                item_id = _normalize_guid(_s(row, "SourceItemId")) if _s(row, "SourceItemId") else ""

            source_table = _s(row, "SourceTableName")

            if(input_lakehouse_schema_name):
                source_schema = input_lakehouse_schema_name
            else:
                source_schema = _s(row, "SourceSchema") or ""

            if not workspace_id or not item_id or not source_table:
                raise ValueError(
                    f"Entity {et_name}: DataBinding requires WorkspaceId, SourceItemId, SourceTableName."
                )

            timestamp_col = _s(row, "TimestampColumnName")
            if db_type == "TimeSeries" and not timestamp_col:
                raise ValueError(
                    f"Entity {et_name}: TimestampColumnName is required when DataBindingType=TimeSeries."
                )

            if(input_eventhouse_cluster_uri):
                cluster_uri = input_eventhouse_cluster_uri
            else:   
                cluster_uri = _s(row, "ClusterUri")

            if(input_eventhouse_database_name):
                database_name = input_eventhouse_database_name   
            else:   
                database_name = _s(row, "DatabaseName")
                
            if source_type == "KustoTable":
                if(input_eventhouse_item_id):
                    item_id = _normalize_guid(input_eventhouse_item_id)
                else:
                    item_id = _normalize_guid(_s(row, "SourceItemId")) if _s(row, "SourceItemId") else ""

                if not cluster_uri or not database_name:
                    raise ValueError(
                        f"Entity {et_name}: ClusterUri and DatabaseName are required when SourceType=KustoTable."
                    )
                if db_type != "TimeSeries":
                    raise ValueError(
                        f"Entity {et_name}: KustoTable bindings are only valid for TimeSeries."
                    )

            # Determine binding id
            # binding_id_raw = _s(row, "BindingId")
            # if binding_id_raw:
            #     binding_id = _normalize_guid(binding_id_raw)
            # else:
            seed = (
                f"databinding:{namespace}:{et['id']}:{db_type}:{source_type}:"
                f"{workspace_id}:{item_id}:{source_schema}:{source_table}:{timestamp_col}:{cluster_uri}:{database_name}"
            )
            binding_id = make_deterministic_guid(seed)

            binding_key = binding_id  # easiest: key by GUID
            acc_key = (et["id"], binding_key)

            if acc_key not in bindings_acc:
                # Build sourceTableProperties
                if source_type == "LakehouseTable":
                    source_table_props = {
                        "sourceType": "LakehouseTable",
                        "workspaceId": workspace_id,
                        "itemId": item_id,
                        "sourceTableName": source_table,
                    }
                    if source_schema:
                        source_table_props["sourceSchema"] = source_schema
                else:
                    # KustoTable
                    source_table_props = {
                        "sourceType": "KustoTable",
                        "workspaceId": workspace_id,
                        "itemId": item_id,
                        "clusterUri": cluster_uri,
                        "databaseName": database_name,
                        "sourceTableName": source_table,
                    }

                data_binding_config: Dict[str, Any] = {
                    "dataBindingType": db_type,
                    "propertyBindings": [],
                    "sourceTableProperties": source_table_props,
                }
                if db_type == "TimeSeries":
                    data_binding_config["timestampColumnName"] = timestamp_col

                bindings_acc[acc_key] = {
                    "entityTypeId": et["id"],
                    "dataBindingId": binding_id,
                    "dataBinding": {
                        "id": binding_id,
                        "dataBindingConfiguration": data_binding_config,
                    },
                    # internal de-dupe
                    "_seen_pairs": set(),
                }

            # Add property binding from this row (if property present)
            raw_prop_name = _s(row, "PropertyName")
            if not raw_prop_name:
                continue

            # target property lookup: accept either "TargetPropertyName" or "PropertyName"
            target_prop_name = _s(row, "TargetPropertyName") or raw_prop_name
            target_prop_id = raw_prop_to_id[et_name].get(
                sanitize_name(target_prop_name, "P").lower()
            )
            if not target_prop_id:
                # fallback: attempt direct (if CSV used already-sanitized)
                target_prop_id = raw_prop_to_id[et_name].get(
                    target_prop_name.strip().lower()
                )

            if not target_prop_id:
                # Skip silently or raise; raising is safer to avoid broken bindings
                raise ValueError(
                    f"Entity {et_name}: Could not resolve target property id for property {target_prop_name!r}."
                )

            source_col = (
                _s(row, "BindingSourceColumnName")
                or _s(row, "SourceColumnName")
                or raw_prop_name
            )
            if not source_col:
                continue

            pair_key = (source_col, target_prop_id)
            acc = bindings_acc[acc_key]
            if pair_key in acc["_seen_pairs"]:
                continue
            acc["_seen_pairs"].add(pair_key)

            acc["dataBinding"]["dataBindingConfiguration"]["propertyBindings"].append(
                {
                    "sourceColumnName": source_col,
                    "targetPropertyId": target_prop_id,
                }
            )

    # finalize list
    out: List[Dict[str, Any]] = []
    for acc in bindings_acc.values():
        acc.pop("_seen_pairs", None)
        # if propertyBindings ended up empty, don't emit
        pbs = (
            acc["dataBinding"]["dataBindingConfiguration"].get("propertyBindings") or []
        )
        if pbs:
            out.append(acc)
    return out


# -----------------------------
# Relationship Contextualizations
# -----------------------------


def build_relationship_type_contextualizations(
    relationship_csv_path_or_bytes: Union[str, bytes],
    relationship_types: List[Dict],
    entity_types: Dict[str, Dict],
    namespace: str,
    input_workspace_id: str = "",
    input_lakehouse_item_id: str = "",
    input_lakehouse_schema_name: str = "",
) -> List[Dict[str, Any]]:
    """
    Builds Contextualization files (parts) per relationship type from OPTIONAL columns in the relationships CSV.

    OPTIONAL columns:
      - ContextualizationId       (GUID optional; if empty, generated deterministically)
      - WorkspaceId               (GUID)   [lakehouse workspace]
      - ItemId                    (GUID)   [lakehouse ArtifactId]
      - SourceTableName           (string)
      - SourceSchema              (string optional)
      - SourceType                (optional; defaults to LakehouseTable)

      - SourceKeyColumnNames      (delimited list: comma/semicolon/pipe)
      - TargetKeyColumnNames      (delimited list: comma/semicolon/pipe)
        (If you only have one key each, you can also use SourceKeyColumnName / TargetKeyColumnName)

    It maps those columns to the *entityIdParts* property IDs of the source/target entity types.
    """
    # Build a quick match map: (srcName, tgtName, relNameSanitizedLower) -> relType
    rel_map: Dict[Tuple[str, str, str], Dict] = {}
    for rt in relationship_types:
        src = rt.get("_srcEntityTypeName") or ""
        tgt = rt.get("_tgtEntityTypeName") or ""
        rel_name = (rt.get("name") or "").lower()
        rel_map[(src, tgt, rel_name)] = rt

    out: List[Dict[str, Any]] = []

    with open_csv_text(relationship_csv_path_or_bytes) as f:
        reader = csv.DictReader(f)
        for row in reader:
            src_name = _s(row, "SourceEntityTypeName")
            tgt_name = _s(row, "TargetEntityTypeName")
            if not src_name or not tgt_name:
                continue

            raw_rel_name = _s(row, "RelationshipName") or f"{src_name}_to_{tgt_name}"
            rel_name = sanitize_name(raw_rel_name, "R").lower()

            rt = rel_map.get((src_name, tgt_name, rel_name))
            if not rt:
                # If relationshipTypes were generated with a default name, try that
                default_rel_name = sanitize_name(
                    f"{src_name}_to_{tgt_name}", "R"
                ).lower()
                rt = rel_map.get((src_name, tgt_name, default_rel_name))
            if not rt:
                continue

            # detect whether this row has contextualization details
            required_columns = [
                "SourceTableName",
                "SourceKeyColumnNames",
                "TargetKeyColumnNames",
            ]
            if not _has_any(row, required_columns):
                continue

            if any(not str(row.get(c, "")).strip() for c in required_columns):
                continue

            if(input_workspace_id):
                workspace_id = _normalize_guid(input_workspace_id)
            else:
                workspace_id = _normalize_guid(_s(row, "WorkspaceId")) if _s(row, "WorkspaceId") else ""
                
            if(input_lakehouse_item_id):
                item_id = _normalize_guid(input_lakehouse_item_id)
            else:
                item_id = _normalize_guid(_s(row, "ItemId")) if _s(row, "ItemId") else ""

            source_table = _s(row, "SourceTableName")
            
            if(input_lakehouse_schema_name):
                source_schema = input_lakehouse_schema_name
            else:
                source_schema = _s(row, "SourceSchema")

            source_type = _s(row, "SourceType") or "LakehouseTable"
            if source_type != "LakehouseTable":
                raise ValueError(
                    "Contextualization currently supports only LakehouseTable sourceType."
                )

            if not workspace_id or not item_id or not source_table:
                raise ValueError(
                    f"Relationship {raw_rel_name}: Contextualization requires WorkspaceId, ItemId, SourceTableName."
                )

            src_et = entity_types.get(src_name)
            tgt_et = entity_types.get(tgt_name)
            if not src_et or not tgt_et:
                continue

            src_key_prop_ids = src_et.get("entityIdParts") or []
            tgt_key_prop_ids = tgt_et.get("entityIdParts") or []
            if not src_key_prop_ids or not tgt_key_prop_ids:
                raise ValueError(
                    f"Relationship {raw_rel_name}: Source/Target entity types must have entityIdParts defined."
                )

            src_cols = _parse_list(_s(row, "SourceKeyColumnNames")) or _parse_list(
                _s(row, "SourceKeyColumnName")
            )
            tgt_cols = _parse_list(_s(row, "TargetKeyColumnNames")) or _parse_list(
                _s(row, "TargetKeyColumnName")
            )

            if len(src_cols) != len(src_key_prop_ids):
                raise ValueError(
                    f"Relationship {raw_rel_name}: number of SourceKeyColumnNames ({len(src_cols)}) "
                    f"must match source entityIdParts ({len(src_key_prop_ids)})."
                )
            if len(tgt_cols) != len(tgt_key_prop_ids):
                raise ValueError(
                    f"Relationship {raw_rel_name}: number of TargetKeyColumnNames ({len(tgt_cols)}) "
                    f"must match target entityIdParts ({len(tgt_key_prop_ids)})."
                )

            # ctx_id_raw = _s(row, "ContextualizationId")
            # if ctx_id_raw:
            #     ctx_id = _normalize_guid(ctx_id_raw)
            # else:
            seed = (
                f"context:{namespace}:{rt['id']}:{workspace_id}:{item_id}:{source_schema}:{source_table}:"
                f"S={','.join(src_cols)}|T={','.join(tgt_cols)}"
            )
            ctx_id = make_deterministic_guid(seed)

            data_binding_table = {
                "workspaceId": workspace_id,
                "itemId": item_id,
                "sourceTableName": source_table,
                "sourceType": "LakehouseTable",
            }
            if source_schema:
                data_binding_table["sourceSchema"] = source_schema

            source_key_ref_bindings = [
                {"sourceColumnName": c, "targetPropertyId": pid}
                for c, pid in zip(src_cols, src_key_prop_ids)
            ]
            target_key_ref_bindings = [
                {"sourceColumnName": c, "targetPropertyId": pid}
                for c, pid in zip(tgt_cols, tgt_key_prop_ids)
            ]

            ctx = {
                "id": ctx_id,
                "dataBindingTable": data_binding_table,
                "sourceKeyRefBindings": source_key_ref_bindings,
                "targetKeyRefBindings": target_key_ref_bindings,
            }

            out.append(
                {
                    "relationshipTypeId": rt["id"],
                    "contextualizationId": ctx_id,
                    "contextualization": ctx,
                }
            )

    return out


# -----------------------------
# Build ontology parts document
# -----------------------------


def build_ontology_parts_document(
    entity_types: Dict[str, Dict],
    relationship_types: List[Dict],
    display_name: str,
    data_bindings: Optional[List[Dict[str, Any]]] = None,
    contextualizations: Optional[List[Dict[str, Any]]] = None,
) -> Dict:
    """
    Build Fabric Ontology definition payload with "parts":
      - .platform
      - definition.json
      - EntityTypes/{ID}/definition.json
      - EntityTypes/{ID}/DataBindings/{GUID}.json
      - RelationshipTypes/{ID}/definition.json
      - RelationshipTypes/{ID}/Contextualizations/{GUID}.json
    """
    parts: List[Dict[str, str]] = []

    parts.append(
        {
            "path": ".platform",
            "payload": encode_base64_json(
                {"metadata": {"type": "Ontology", "displayName": display_name}}
            ),
            "payloadType": "InlineBase64",
        }
    )

    parts.append(
        {
            "path": "definition.json",
            "payload": encode_base64_json({}),
            "payloadType": "InlineBase64",
        }
    )

    # EntityTypes
    for et in sorted(entity_types.values(), key=lambda e: e["id"]):
        parts.append(
            {
                "path": f"EntityTypes/{et['id']}/definition.json",
                "payload": encode_base64_json(_strip_internal_fields(et)),
                "payloadType": "InlineBase64",
            }
        )

    # Entity DataBindings
    for db in sorted(
        (data_bindings or []), key=lambda x: (x["entityTypeId"], x["dataBindingId"])
    ):
        parts.append(
            {
                "path": f"EntityTypes/{db['entityTypeId']}/DataBindings/{db['dataBindingId']}.json",
                "payload": encode_base64_json(db["dataBinding"]),
                "payloadType": "InlineBase64",
            }
        )

    # RelationshipTypes
    for rt in sorted(relationship_types, key=lambda r: r["id"]):
        parts.append(
            {
                "path": f"RelationshipTypes/{rt['id']}/definition.json",
                "payload": encode_base64_json(_strip_internal_fields(rt)),
                "payloadType": "InlineBase64",
            }
        )

    # Relationship Contextualizations
    for cx in sorted(
        (contextualizations or []),
        key=lambda x: (x["relationshipTypeId"], x["contextualizationId"]),
    ):
        parts.append(
            {
                "path": f"RelationshipTypes/{cx['relationshipTypeId']}/Contextualizations/{cx['contextualizationId']}.json",
                "payload": encode_base64_json(cx["contextualization"]),
                "payloadType": "InlineBase64",
            }
        )

    return {"parts": parts}


def _strip_internal_fields(obj: Any) -> Any:
    """
    Remove helper fields (like _srcEntityTypeName) from emitted JSON.
    Works recursively for dict/list.
    """
    if isinstance(obj, list):
        return [_strip_internal_fields(x) for x in obj]
    if isinstance(obj, dict):
        return {
            k: _strip_internal_fields(v)
            for k, v in obj.items()
            if not k.startswith("_")
        }
    return obj


### -------------- Generate Ontology Definition -------------- ###

def generate_definition_from_package(
    ontology_package_path: str,
    ontology_name: str,
    binding_workspace_id: str = "",
    binding_lakehouse_item_id: str = "",
    binding_lakehouse_schema_name: str = "",
    binding_eventhouse_item_id: str = "",
    binding_eventhouse_cluster_uri: str = "",
    binding_eventhouse_database_name: str = "",
    namespace: str = "usertypes"
) -> tuple[Dict, Dict[str, Dict], List[Dict]]:

    #definition_zip_bytes = read_zip_bytes_from_ontology_package(ontology_package_path,"definition")
    with ZipFile(ontology_package_path) as zf:
        entity_type_bytes = io.BytesIO(zf.read("definition/entity_types.csv"))
        relationship_type_bytes = io.BytesIO(zf.read("definition/relationship_types.csv"))
        entity_types = build_entity_types(entity_type_bytes, namespace=namespace)
        relationship_types = build_relationship_types(
            relationship_type_bytes, entity_types=entity_types, namespace=namespace
        )

    contextualizations: List[Dict[str, Any]] = []
    data_bindings: List[Dict[str, Any]] = []

    #binding_zip_bytes = read_zip_bytes_from_ontology_package(ontology_package_path,"binding")
    with ZipFile(ontology_package_path) as zf:
        binding_entity_type_bytes = io.BytesIO(zf.read("binding/binding_entity_types.csv"))
        binding_relationship_type_bytes = io.BytesIO(zf.read("binding/binding_relationship_types.csv"))
        data_bindings = build_entity_type_data_bindings(
            binding_entity_type_bytes,
            entity_types=entity_types,
            namespace=namespace, 
            input_workspace_id=binding_workspace_id,
            input_lakehouse_item_id=binding_lakehouse_item_id,
            input_lakehouse_schema_name=binding_lakehouse_schema_name,
            input_eventhouse_item_id=binding_eventhouse_item_id,
            input_eventhouse_cluster_uri=binding_eventhouse_cluster_uri,
            input_eventhouse_database_name=binding_eventhouse_database_name
        )

        contextualizations = build_relationship_type_contextualizations(
            binding_relationship_type_bytes,
            relationship_types=relationship_types,
            entity_types=entity_types,
            namespace=namespace,
            input_workspace_id=binding_workspace_id,
            input_lakehouse_item_id=binding_lakehouse_item_id,
            input_lakehouse_schema_name=binding_lakehouse_schema_name,
        )

    return (
        build_ontology_parts_document(
            entity_types=entity_types,
            relationship_types=relationship_types,
            display_name=ontology_name,
            data_bindings=data_bindings,
            contextualizations=contextualizations,
        ),
        entity_types,
        relationship_types,
        data_bindings,
        contextualizations,
    )