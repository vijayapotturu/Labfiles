from __future__ import annotations

import base64
import hashlib
from itertools import islice
import json
import re
from typing import Dict, List

from rdflib import Graph, RDF, RDFS, OWL, URIRef, BNode
from rdflib.namespace import XSD

MAX_ENTITY_TYPES = 500  

def data_type_validation(value_type: str) -> None:
    allowed_types = ["String", "Boolean","DateTime", "BigInt", "Double"]
    
    if value_type not in allowed_types:
        raise ValueError(
            f"Invalid data type: {value_type!r}. Allowed values are: {allowed_types}"
        )

# ---------------------- ID & naming helpers ---------------------- #

def make_64bit_id(seed: str) -> int:
    """
    Deterministically generate a positive 64-bit integer from a string seed.
    Fabric IDs are positive 64-bit integers ("BigInt"). :contentReference[oaicite:3]{index=3}
    """
    h = hashlib.sha256(seed.encode("utf-8")).digest()
    val = int.from_bytes(h[:8], "big") & ((1 << 63) - 1)  # ensure positive
    if val == 0:
        val = 1
    return val


def iri_local_name(iri: str) -> str:
    """
    Extract local name from an IRI (after '#' or last '/').
    """
    if "#" in iri:
        candidate = iri.rsplit("#", 1)[1]
    else:
        # strip trailing '/' then take last segment
        candidate = iri.rstrip("/").rsplit("/", 1)[-1]
    return candidate or "Thing"


def sanitize_name(name: str, prefix: str) -> str:
    """
    Conform to the EntityType / Property / Relationship name regex:

      ^[a-zA-Z][a-zA-Z0-9_-]{0,127}$

    (Docs show '\\$' at the end of the regex in JSON, but the intended
    pattern is the standard one above.) :contentReference[oaicite:4]{index=4}
    """
    # Replace invalid chars with '_'
    clean = re.sub(r"[^A-Za-z0-9_-]", "_", name)
    # Ensure starts with a letter
    if not clean or not clean[0].isalpha():
        clean = f"{prefix}_{clean}" if clean else f"{prefix}"
    # Truncate to max length 128
    return clean[:128]


def xsd_to_value_type(dt: URIRef) -> str:
    """
    Map XSD datatypes to Fabric EntityTypeProperty.valueType.
    Allowed values: String, Boolean, DateTime, Object, BigInt, Double. :contentReference[oaicite:5]{index=5}
    """
    if dt in {
        XSD.string, XSD.normalizedString, XSD.token, XSD.language,
        XSD.Name, XSD.NCName, XSD.anyURI,
    }:
        return "String"
    if dt == XSD.boolean:
        return "Boolean"
    if dt in {XSD.dateTime, XSD.dateTimeStamp, XSD.date, XSD.time}:
        return "DateTime"
    if dt in {XSD.float, XSD.double, XSD.decimal}:
        return "Double"
    if dt in {
        XSD.integer, XSD.nonNegativeInteger, XSD.positiveInteger,
        XSD.negativeInteger, XSD.nonPositiveInteger,
        XSD.long, XSD.int, XSD.short, XSD.byte,
        XSD.unsignedLong, XSD.unsignedInt,
        XSD.unsignedShort, XSD.unsignedByte,
    }:
        return "BigInt"
    # Fallback
    return "String"


def encode_base64_json(obj) -> str:
    """
    JSON-serialize and base64-encode a payload for Fabric's "InlineBase64". :contentReference[oaicite:6]{index=6}
    """
    data = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.b64encode(data).decode("ascii")


# ---------------------- Core extraction logic ---------------------- #

def build_entity_types(graph: Graph, namespace: str) -> Dict[URIRef, Dict]:
    """
    Build EntityType definitions (including EntityTypeProperty arrays) from RDF.

    Returns:
        dict: { class_uri: entity_type_dict }
    """
    classes = set()

    # 1) Explicit OWL/RDFS classes
    for s in graph.subjects(RDF.type, OWL.Class):
        if isinstance(s, URIRef):
            classes.add(s)
    for s in graph.subjects(RDF.type, RDFS.Class):
        if isinstance(s, URIRef):
            classes.add(s)

    # # 2) Anything used as domain/range becomes a class as well
    # for o in graph.objects(None, RDFS.domain):
    #     if isinstance(o, URIRef):
    #         classes.add(o)
    # for o in graph.objects(None, RDFS.range):
    #     if isinstance(o, URIRef):
    #         classes.add(o)

    entity_types: Dict[URIRef, Dict] = {}

    # First create stubs (without properties)
    for c in sorted(classes, key=lambda u: str(u))[:MAX_ENTITY_TYPES]:
        if isinstance(c, BNode):
            # Skip blank-node classes
            continue
        cid = str(make_64bit_id(f"entity:{str(c)}"))
        raw_name = iri_local_name(str(c))
        name = sanitize_name(raw_name, prefix="E")

        entity_types[c] = {
            "id": cid,
            "namespace": namespace,
            "baseEntityTypeId": None,
            "name": name,
            #"entityIdParts": [],
            "displayNamePropertyId": None,
            "namespaceType": "Custom",
            "visibility": "Visible",
            "properties": [],
            "timeseriesProperties": [],
        }

    # Map subclass hierarchy to baseEntityTypeId when possible
    # for child, parent in graph.subject_objects(RDFS.subClassOf):
    #     if isinstance(child, URIRef) and isinstance(parent, URIRef):
    #         if child in entity_types and parent in entity_types:
    #             entity_types[child]["baseEntityTypeId"] = entity_types[parent]["id"]

    # Now add properties (EntityTypeProperty)
    add_entity_properties(graph, entity_types)

    return entity_types


def add_entity_properties(graph: Graph, entity_types: Dict[URIRef, Dict]):
    """
    Populate EntityType.properties from OWL DatatypeProperties.
    """
    datatype_props = set(graph.subjects(RDF.type, OWL.DatatypeProperty))

    # Fallback: RDF.Property with XSD ranges
    for p in graph.subjects(RDF.type, RDF.Property):
        if p in datatype_props:
            continue
        for r in graph.objects(p, RDFS.range):
            if isinstance(r, URIRef) and str(r).startswith(str(XSD)):
                datatype_props.add(p)
                break

    for p in sorted(datatype_props, key=lambda u: str(u)):
        if isinstance(p, BNode):
            continue

        # Domains: which entity types should get this property?
        domains = [d for d in graph.objects(p, RDFS.domain)
                   if isinstance(d, URIRef) and d in entity_types]

        if not domains:
            # If no explicit domain, we could apply to all entity types,
            # but for now we only use explicit domain to avoid noise.
            continue

        # Range → valueType
        ranges = [r for r in graph.objects(p, RDFS.range) if isinstance(r, URIRef)]
        if ranges:
            value_type = xsd_to_value_type(ranges[0])
        else:
            # Default if no explicit range
            value_type = "String"
        
        data_type_validation(value_type)

        raw_name = iri_local_name(str(p))
        prop_name = sanitize_name(raw_name, prefix="P")

        for d in domains:
            et = entity_types.get(d)
            if not et:
                continue

            pid = str(make_64bit_id(f"prop:{str(p)}|{str(d)}"))

            prop_def = {
                "id": pid,
                "name": prop_name,
                "redefines": None,
                "baseTypeNamespaceType": None,
                "valueType": value_type,
            }

            et["properties"].append(prop_def)

            # Optional: if entityIdParts/displayNamePropertyId is empty,
            # we could pick the first property as an identifier/display name.
            # if not et["entityIdParts"]:
            #     et["entityIdParts"] = [pid]
            #     et["displayNamePropertyId"] = pid


def build_relationship_types(graph: Graph, entity_types: Dict[URIRef, Dict], namespace: str) -> List[Dict]:
    """
    Build RelationshipType definitions from OWL ObjectProperties:

    - source.entityTypeId ← domain class
    - target.entityTypeId ← range class

    Follows the RelationshipType schema from the REST docs. :contentReference[oaicite:7]{index=7}
    """
    relationships: List[Dict] = []

    object_props = set(graph.subjects(RDF.type, OWL.ObjectProperty))

    # Fallback: treat RDF.Property with class-like ranges as object properties
    for p in graph.subjects(RDF.type, RDF.Property):
        if p in object_props:
            continue
        has_class_range = any(
            isinstance(r, URIRef) and r in entity_types
            for r in graph.objects(p, RDFS.range)
        )
        if has_class_range:
            object_props.add(p)

    seen_seeds = set()

    for p in sorted(object_props, key=lambda u: str(u)):
        if isinstance(p, BNode):
            continue

        domains = [d for d in graph.objects(p, RDFS.domain)
                   if isinstance(d, URIRef) and d in entity_types]
        ranges = [r for r in graph.objects(p, RDFS.range)
                  if isinstance(r, URIRef) and r in entity_types]

        if not domains or not ranges:
            # Skip relationships without well-defined domain & range
            continue

        raw_name = iri_local_name(str(p))
        rel_name = sanitize_name(raw_name, prefix="R")

        for d in domains:
            for r in ranges:
                seed = f"{str(p)}|{str(d)}->{str(r)}"
                if seed in seen_seeds:
                    continue
                seen_seeds.add(seed)

                rid = str(make_64bit_id(f"rel:{seed}"))

                # handle multiple domains/ranges by creating distinct relationships
                new_rel_name = f"{rel_name}_{entity_types[d]['name']}_to_{entity_types[r]['name']}"
                rel_def = {
                    "namespace": namespace,
                    "id": rid,
                    "name": new_rel_name,
                    "namespaceType": "Custom",
                    "source": {
                        "entityTypeId": entity_types[d]["id"]
                    },
                    "target": {
                        "entityTypeId": entity_types[r]["id"]
                    }
                }
                relationships.append(rel_def)

    return relationships


# ---------------------- Build Fabric "parts" document ---------------------- #

def build_ontology_parts_document(
    entity_types: Dict[URIRef, Dict],
    relationship_types: List[Dict],
    display_name: str,
) -> Dict:
    """
    Build the full Fabric Ontology definition payload with "parts":

    - .platform (PlatformDetails)
    - definition.json (root DefinitionDetails, empty {})
    - EntityTypes/{ID}/definition.json (EntityType)
    - RelationshipTypes/{ID}/definition.json (RelationshipType)
    """
    parts = []
    
    # # # Save entity_types to a JSON file
    # # with open("entity_types.json", "w") as f:
    # #     json.dump(entity_types, f, indent=2)
    # # with open("relationship_types.json", "w") as f:
    # #     json.dump(relationship_types, f, indent=2)

    # .platform → PlatformDetails
    platform = {
        "metadata": {
            "type": "Ontology",
            "displayName": display_name,
        }
    }
    parts.append({
        "path": ".platform",
        "payload": encode_base64_json(platform),
        "payloadType": "InlineBase64",
    })

    # Root definition.json → DefinitionDetails (empty {})
    parts.append({
        "path": "definition.json",
        "payload": encode_base64_json({}),
        "payloadType": "InlineBase64",
    })

    # EntityTypes/{ID}/definition.json
    for et in sorted(entity_types.values(), key=lambda e: e["id"]):
        parts.append({
            "path": f"EntityTypes/{et['id']}/definition.json",
            "payload": encode_base64_json(et),
            "payloadType": "InlineBase64",
        })

    # RelationshipTypes/{ID}/definition.json
    for rt in sorted(relationship_types, key=lambda r: r["id"]):
        parts.append({
            "path": f"RelationshipTypes/{rt['id']}/definition.json",
            "payload": encode_base64_json(rt),
            "payloadType": "InlineBase64",
        })

    return {"parts": parts}

def generate_definition_from_rdf(
    rdf_content: str,
    rdf_format: str = "turtle",
    ontology_name: str = "ontology",
    namespace: str = "usertypes",
) -> tuple[Dict, Dict[URIRef, Dict], List[Dict]]:
    """
    High-level API:

    - Parse RDF from `rdf_content`
    - Build EntityTypes, EntityTypeProperties, RelationshipTypes
    - Return Fabric Ontology definition ("parts" JSON).
    """
    g = Graph()
    g.parse(data=rdf_content, format=rdf_format)

    entity_types = build_entity_types(g, namespace=namespace)
    relationship_types = build_relationship_types(g, entity_types, namespace=namespace)

    return build_ontology_parts_document(
        entity_types=entity_types,
        relationship_types=relationship_types,
        display_name=ontology_name,
    ), entity_types, relationship_types