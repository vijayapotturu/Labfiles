from __future__ import annotations

import io
import re
from zipfile import ZipFile
from typing import Dict, Iterable, Optional
import pandas as pd

def read_zip_bytes_from_ontology_package(ontology_package_zip_path: str, inner_zip_name:str ) -> bytes:
    ontology_zip_path = str(ontology_package_zip_path)

    with ZipFile(ontology_zip_path, "r") as outer:
        with outer.open(f"{inner_zip_name}.zip") as inner_zip_bytes:
           return inner_zip_bytes.read()

def _sanitize_table_name(name: str) -> str:
    base = name.split("/")[-1].split("\\")[-1]
    base = re.sub(r"\.csv$", "", base, flags=re.IGNORECASE)
    base = re.sub(r"[^0-9a-zA-Z]+", "_", base).strip("_").lower()
    if not base or base[0].isdigit():
        base = f"t_{base}"
    return base

def _is_csv(member_name: str) -> bool:
    return member_name.lower().endswith(".csv") and not member_name.endswith("/")

def infer_datetime_columns(df: pd.DataFrame, sample_size: int = 100, success_ratio: float = 0.9):
    """
    A column is considered datetime if at least `success_ratio` of sampled non-empty values
    can be parsed by pd.to_datetime().
    """
    dt_cols = []

    for col in df.columns:
        s = df[col].dropna()
        if s.empty:
            continue

        # sample a few non-empty values
        s = s.astype(str).str.strip()
        s = s[s != ""].head(sample_size)
        if s.empty:
            continue

        parsed = pd.to_datetime(s, errors="coerce", format="mixed")
        if (parsed.notna().mean() >= success_ratio):
            dt_cols.append(col)

    return dt_cols

def generate_instance_data(
    spark,
    ontology_package_path: str,
    table_prefix: str = "",
    database: Optional[str] = None,
    mode: str = "overwrite",
    encoding: Optional[str] = None,
) -> Dict[str, str]:

    created: Dict[str, str] = {}

    #instance_data_zip_bytes = read_zip_bytes_from_ontology_package(ontology_package_path,"instance_data")
    zf = ZipFile(ontology_package_path)
    members = [m for m in zf.namelist() if m.startswith("instance_data/") and _is_csv(m)]

    for member in members:
        table_name = f"{table_prefix}{_sanitize_table_name(member)}"
        full_table_name = f"{database}.{table_name}" if database else table_name

        csv_bytes = zf.read(member)
        dt_cols = []

        # sample = pd.read_csv(io.BytesIO(csv_bytes),encoding=encoding)
        # if("timestampUTC" in sample.columns):
        #     dt_cols.append("timestampUTC")
        #pdf = pd.read_csv(io.BytesIO(csv_bytes),parse_dates=dt_cols,encoding=encoding)

        df_csv = pd.read_csv(io.BytesIO(csv_bytes),encoding=encoding)
        dt_cols = infer_datetime_columns(df_csv)
        for c in dt_cols:
            df_csv[c] = pd.to_datetime(df_csv[c], errors="coerce",format="mixed")


        sdf = spark.createDataFrame(df_csv)

        (sdf.write
            .format("delta")
            .mode(mode)
            .saveAsTable(full_table_name)
        )

        created[member] = full_table_name
        print(f"Delta table -> {full_table_name}")

    return created

def generate_events_data(
    spark,
    ontology_package_path: str,
    eventhouse_cluster_uri: str,
    eventhouse_database: str,
    access_token: str,
    table_prefix: str = "",
    encoding: Optional[str] = None,
) -> Dict[str, str]:

    created: Dict[str, str] = {}

    #events_data_zip_bytes = read_zip_bytes_from_ontology_package(ontology_package_path,"events_data")
    zf = ZipFile(ontology_package_path)
    members = [m for m in zf.namelist() if m.startswith("events_data/") and _is_csv(m)]

    for member in members:
        table_name = f"{table_prefix}{_sanitize_table_name(member)}"
        csv_bytes = zf.read(member)
        dt_cols = []

        df_csv = pd.read_csv(io.BytesIO(csv_bytes),encoding=encoding)
        dt_cols = infer_datetime_columns(df_csv)
        for c in dt_cols:
            df_csv[c] = pd.to_datetime(df_csv[c], errors="coerce",format="mixed")

        sdf = spark.createDataFrame(df_csv)

        (sdf.write
            .format("com.microsoft.kusto.spark.synapse.datasource")
            .option("kustoCluster",eventhouse_cluster_uri)
            .option("kustoDatabase",eventhouse_database)
            .option("kustoTable", table_name)
            .option("accessToken", access_token)
            .option("tableCreateOptions", "CreateIfNotExist")
            .mode("Append")
            .save()
        )

        created[member] = table_name
        print(f"Kusto table -> {table_name}")

    return created